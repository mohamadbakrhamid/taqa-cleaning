TAQA SOLAR — Module Cleaning Web App
-----------------------------------

Quick start:
1. Unzip the project.
2. Open the folder in your computer.
3. Install dependencies: `npm install`
4. Replace the FIREBASE_CONFIG placeholder in src/App.js with your Firebase project config.
5. Run locally: `npm start`
6. To deploy on Vercel: push the repo to GitHub and use "Import Project" on vercel.com or use the Vercel CLI.

Firebase setup summary:
- Create a Firebase project at https://console.firebase.google.com
- Enable Authentication -> Email/Password
- Create Firestore database (Firestore in Native mode)
- Enable Storage
- In Firebase Console -> Project Settings -> SDK config, copy the config object and paste into src/App.js FIREBASE_CONFIG

Admin instructions:
- After deployment, create your admin account by signing up with your admin email.
- In Firestore rules you can secure update/delete so only the creator or admin may modify:
  Example:
  match /module_cleaning/{doc} {
    allow read: if request.auth != null;
    allow create: if request.auth != null;
    allow update, delete: if request.auth != null && (request.auth.uid == resource.data.createdBy || request.auth.token.admin == true);
  }
