import React, { useState, useEffect, useRef } from 'react';
import './styles.css';

// Replace this FIREBASE_CONFIG with your Firebase project's config
const FIREBASE_CONFIG = {
  apiKey: "REPLACE_API_KEY",
  authDomain: "REPLACE_PROJECT.firebaseapp.com",
  projectId: "REPLACE_PROJECT",
  storageBucket: "REPLACE_PROJECT.appspot.com",
  messagingSenderId: "REPLACE_SENDER_ID",
  appId: "REPLACE_APP_ID",
};

import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, collection, addDoc, query, orderBy, onSnapshot, doc, updateDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref as storageRef, uploadString, getDownloadURL, deleteObject } from 'firebase/storage';

const app = initializeApp(FIREBASE_CONFIG);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export default function App(){
  const [user,setUser] = useState(null);
  const [mode,setMode] = useState('login');
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [records,setRecords] = useState([]);
  const [columnNo,setColumnNo] = useState(1);
  const [rowNo,setRowNo] = useState(1);
  const [cleaningType,setCleaningType] = useState('Manual Cleaning');
  const [quality,setQuality] = useState('Good');
  const [remarks,setRemarks] = useState('');
  const [imageDataUrl,setImageDataUrl] = useState(null);
  const [editingId,setEditingId] = useState(null);
  const fileRef = useRef();

  useEffect(()=>{
    const unsub = onAuthStateChanged(auth, u=> setUser(u));
    return () => unsub();
  },[]);

  useEffect(()=>{
    if(!user){ setRecords([]); return; }
    const coll = collection(db,'module_cleaning');
    const q = query(coll, orderBy('createdAt','desc'));
    const unsub = onSnapshot(q, snap=>{
      const arr=[];
      snap.forEach(s=> arr.push({ id:s.id, ...s.data() }));
      setRecords(arr);
    });
    return ()=>unsub();
  },[user]);

  const signup = async ()=>{ try{ await createUserWithEmailAndPassword(auth,email,password); setEmail(''); setPassword(''); }catch(e){alert(e.message)} };
  const login = async ()=>{ try{ await signInWithEmailAndPassword(auth,email,password); setEmail(''); setPassword(''); }catch(e){alert(e.message)} };
  const logout = async ()=>{ await signOut(auth); };

  const onPick = e => {
    const f = e.target.files && e.target.files[0];
    if(!f) return;
    const reader = new FileReader();
    reader.onload = (ev)=> setImageDataUrl(ev.target.result);
    reader.readAsDataURL(f);
  };

  const addOrUpdate = async (e) => {
    e.preventDefault();
    if(!user) return alert('Please login');
    try{
      let imageUrl=null, imagePath=null;
      if(imageDataUrl){
        const path = `module_images/${user.uid}_${Date.now()}.jpg`;
        const sRef = storageRef(storage,path);
        await uploadString(sRef, imageDataUrl.split(',')[1], 'base64');
        imageUrl = await getDownloadURL(sRef);
        imagePath = path;
      }
      const payload = {
        siteName: 'TAQA SOLAR',
        columnNo: Number(columnNo),
        rowNo: Number(rowNo),
        cleaningType,
        quality,
        remarks,
        imageUrl,
        imagePath,
        createdBy: user.uid,
        createdAt: serverTimestamp()
      };
      if(editingId){
        await updateDoc(doc(db,'module_cleaning',editingId), {...payload, updatedAt: serverTimestamp()});
      } else {
        await addDoc(collection(db,'module_cleaning'), payload);
      }
      // reset
      setColumnNo(1); setRowNo(1); setCleaningType('Manual Cleaning'); setQuality('Good'); setRemarks(''); setImageDataUrl(null); setEditingId(null);
    }catch(e){ console.error(e); alert('Save failed: '+e.message) }
  };

  const remove = async (r) => {
    if(!window.confirm('Delete?')) return;
    try{
      if(r.imagePath) await deleteObject(storageRef(storage,r.imagePath)).catch(()=>{});
      await deleteDoc(doc(db,'module_cleaning',r.id));
    }catch(e){ alert('Delete failed: '+e.message) }
  };

  const edit = (r)=>{
    setColumnNo(r.columnNo); setRowNo(r.rowNo); setCleaningType(r.cleaningType); setQuality(r.quality); setRemarks(r.remarks||''); setImageDataUrl(r.imageUrl||null); setEditingId(r.id);
    window.scrollTo({top:0,behavior:'smooth'});
  };

  return (
    <div className="container">
      <h2>TAQA SOLAR - Module Cleaning</h2>
      {!user ? (
        <div className="card" style={{marginTop:12}}>
          <h3>{mode==='login'? 'Login':'Sign up'}</h3>
          <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
          <div style={{display:'flex',gap:8,marginTop:8}}>
            {mode==='login' ? <button onClick={login}>Login</button> : <button onClick={signup}>Create</button>}
            <button onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'? 'Create account':'Have an account'}</button>
          </div>
          <small>Use your team email. Admin creates accounts or users signup.</small>
        </div>
      ) : (
        <>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:8}}>
            <div>Signed in: <strong>{user.email}</strong></div>
            <div><button onClick={logout}>Logout</button></div>
          </div>

          <form onSubmit={addOrUpdate} className="card" style={{marginTop:12}}>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
              <div>
                <label>Site</label>
                <input value="TAQA SOLAR" readOnly />
              </div>
              <div>
                <label>Column No</label>
                <select value={columnNo} onChange={e=>setColumnNo(e.target.value)}>{Array.from({length:17},(_,i)=>i+1).map(n=> <option key={n} value={n}>{n}</option>)}</select>
              </div>
              <div>
                <label>Row No</label>
                <select value={rowNo} onChange={e=>setRowNo(e.target.value)}>{Array.from({length:170},(_,i)=>i+1).map(n=> <option key={n} value={n}>{n}</option>)}</select>
              </div>
              <div>
                <label>Cleaning Type</label>
                <select value={cleaningType} onChange={e=>setCleaningType(e.target.value)}><option>Manual Cleaning</option><option>Machine Cleaning</option></select>
              </div>
              <div>
                <label>Quality</label>
                <select value={quality} onChange={e=>setQuality(e.target.value)}><option>Good</option><option>Poor</option></select>
              </div>
              <div>
                <label>Remarks</label>
                <input value={remarks} onChange={e=>setRemarks(e.target.value)} placeholder="Notes..." />
              </div>
              <div style={{gridColumn:'1 / -1'}}>
                <label>Photo</label>
                <input ref={fileRef} type="file" accept="image/*" capture="environment" onChange={onPick} />
                {imageDataUrl && <div style={{marginTop:8}}><img src={imageDataUrl} alt="preview" /></div>}
              </div>
            </div>
            <div style={{marginTop:8,display:'flex',gap:8}}>
              <button type="submit">{editingId? 'Update':'Add record'}</button>
              <button type="button" onClick={()=>{ setColumnNo(1); setRowNo(1); setCleaningType('Manual Cleaning'); setQuality('Good'); setRemarks(''); setImageDataUrl(null); setEditingId(null); }}>Clear</button>
            </div>
          </form>

          <div style={{marginTop:12}}>
            {records.length===0 ? <div className="card">No records yet</div> : records.map(r=>(
              <div key={r.id} className="card" style={{marginTop:8}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:8}}>
                  <div>
                    <div style={{fontWeight:600}}>Column {r.columnNo} / Row {r.rowNo} — {r.cleaningType} <span style={{marginLeft:8,padding:'4px 8px',borderRadius:9999,color:'#fff',backgroundColor:r.quality==='Good'?'#10B981':'#DC2626'}}>{r.quality}</span></div>
                    <div style={{marginTop:6}}>{r.remarks}</div>
                    {r.imageUrl && <div style={{marginTop:8}}><img src={r.imageUrl} alt="photo" /></div>}
                    <div style={{marginTop:6,fontSize:12,color:'#666'}}>By: {r.createdBy}</div>
                  </div>
                  <div style={{display:'flex',flexDirection:'column',gap:6}}>
                    <button onClick={()=>edit(r)}>Edit</button>
                    <button onClick={()=>remove(r)}>Delete</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
